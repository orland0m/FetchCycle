/*
 * Autor: Miramontes Martinez Orlando Ogday
 * Codigo: 209365982
 * Seccion: D02
 * Practica 1 CTF
 */
#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<signal.h>

typedef struct Container{
	uint8_t * liberar;
    uint8_t * data;
    ssize_t size;
    char * prompt;
    ssize_t min_size;
    ssize_t max_size;
}Container;

const char * the_prompt;

int parse(uint8_t c){
	int tmp = c - '0';
	if(tmp>=0&&tmp<=9){
		return tmp;
	}
	return -1;
}

void free_if(void * pointer){
    if(pointer){
        free(pointer);
    }
}

void salir(uint8_t * buffer, ssize_t size){
	if(size==1&&buffer[0]=='\n'){
		printf("Terminado\n");
		exit(0);
	}
}

uint8_t * noCeros(uint8_t * buffer, ssize_t * read){
	int i=0;
	while(buffer[i++] == '0' && i < *read);
	*read -= i; // recortar inicio y salto de linea
	return &buffer[i-1];
}

int siguienteLinea(Container * cubo){
	uint8_t * linea = NULL;
    size_t lon = 0;
    ssize_t read;
    ssize_t i = 0;
    cubo -> data = NULL;
    cubo -> size = 0;
    free_if(cubo->liberar);
    printf(cubo->prompt);
    the_prompt = cubo->prompt;
    int tmp = 0;
	if((read = getline((char **)&linea, &lon, stdin)) != -1){
		salir(linea, read); // Salir cuando sea linea vacia
		cubo->liberar = linea;
		linea = noCeros(linea, &read); // Quitar ceros
		if(read==0){
			if(cubo->min_size==1){
				linea[0] = 0;
				cubo->data = linea;
				cubo->size = 1;
				return 1;
			}
			printf("El numero debe ser mayor a 100,000,000\n");
			return 0;
		}
		for(i=0; i<read; i++){ // Sintaxis
			tmp = parse(linea[i]);
			if(tmp>=0){
				linea[i]=tmp;
			}else{
				printf("Error de sintaxis\n");
				return 0;
			}
		}
		if(cubo->max_size > 0 && read > cubo->max_size){ // Ver si sobrepasa limite
			printf("El Numero exede el maximo permitido: %d\n", cubo->max_size);
			return 0;
		}
		if(read<cubo->min_size){ // Tamanio minimo
			printf("El Numero debe ser mayor (%d digitos minimo)\n", cubo->min_size);
			return 0;
		}
		cubo->data = linea;
		cubo->size = read;
		return 1;
	}else{
		return 0;
	}
}

int count_numbers(Container bignum, Container num){
	ssize_t i = 0, c = 0;
	for(i=0; i< bignum.size; i++){
		if(bignum.data[i] == num.data[0]){
			c++;
		}
	}
	return c;
}

int main(){
    signal(SIGINT, SIG_IGN);
    Container bignum, num;
    bignum.min_size = 9;
    num.min_size = num.max_size = 1;
    bignum.max_size = -1;
    num.liberar = bignum.liberar = num.data = bignum.data = NULL;
	bignum.prompt = "Escribe un numero mayor a 100,000,000 (Enter para salir) > ";
	num.prompt = "Escribe un numero de un digito (Enter para salir) > ";
	system("clear");
    while(1){
    	if(siguienteLinea(&bignum)){
    		if(siguienteLinea(&num)){
    			printf("Tu digito esta contenido %i veces en el numero grande\n", count_numbers(bignum, num));
    		}else{
    			goto input_error;
    		}
    	}else{
    		goto input_error;
    	}
    	continue;
    	input_error:
    	printf("Tu numero no es correcto. Ignorado\n");
    }
    free_if(bignum.liberar);
    free_if(num.liberar);
    num.liberar = bignum.liberar = num.data = bignum.data = NULL;
    return 0;
}
